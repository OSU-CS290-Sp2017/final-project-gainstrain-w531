"# final-project-gainstrain-w531"

USE RAW VIEW METHOD IN GITHUB


My idea of the basic layout of each of the 4 pages is


|           Week 1             |           Week 2             |           Week 3             |           Deload             |
| Set 1 - 5 reps (lbs amount)  | Set 1 - 3 reps (lbs amount)  | Set 1 - 5 reps (lbs amount)  | Set 1 - 5 reps (lbs amount)  |
| Set 2 - 5 reps (lbs amount)  | Set 2 - 3 reps (lbs amount)  | Set 2 - 3 reps (lbs amount)  | Set 2 - 5 reps (lbs amount)  |     
| Set 3 - 5+ reps(lbs amount)  | Set 3 - 3+ reps(lbs amount)  | Set 3 - 1+ reps(lbs amount)  | Set 3 - 5 reps (lbs amount)  |

The  places labeled (lbs amount) would be altered using the modal and calculating the corresponding % from the index.html page
